const contenedor = document.getElementById('resultado');
const mensajeError = document.getElementById('error');



// 1. Cargar los 15 iniciales al abrir

// Esta función se encarga de pedir al servidor la lista de Personajes inicial y convertirla en JSON 
// Es async porque usamos await con fetch, así el flujo queda más claro.
async function cargarPersonajes() {
    try {
        const respuesta = await fetch('/api.attackontitanapi');
        
        if (!respuesta.ok) {
            throw new Error('Error al obtener la lista del servidor');
        }

        const listaPersonajes = await respuesta.json();

        // Limpiamos el contenedor antes  p
        // Si no hacemos esto, se acumulan las tarjetas cada vez que se recarga.
        contenedor.innerHTML = '';

        // Dibujamos las 15 tarjetas una por una.
        // forEach recorre el array, y por cada personaje generamos un bloque de HTML.
        listaPersonajes.forEach(personaje => {
        // Validamos que tipos sea un array antes de usar map
        const tiposHTML = Array.isArray(personaje.tipos) 
                ? personaje.tipos.map(tipo => `<span class="tipo">${tipo}</span>`).join('')
                : `<span class="tipo">${personaje.tipos}</span>`;
                
        const card = `
        <div class="card">
            <img src="${personaje.imagen}" alt="${personaje.nombre}" style="width:100%">
            <h3>#${personaje.id} ${personaje.nombre}</h3>
            <p>Especie: ${personaje.especies}</p>
            <p>Alias: ${personaje.alias}</p>
            <div class="tipos-container">
                ${tiposHTML}
            </div>
        </div>
    `;
    contenedor.innerHTML += card;
    });

    } catch (error) {
        console.error("Error en la carga inicial:", error);
        mensajeError.textContent = "No se pudo cargar la lista.";
        mensajeError.classList.remove('hidden');
    }
    }
// INICIO AUTOMÁTICO
// Con esto hacemos que la app sea "plug and play": carga sola nada más abrir.
// No tienes que presionar nada, el navegador ya EJECUTA la función al principio.
cargarPersonajes();