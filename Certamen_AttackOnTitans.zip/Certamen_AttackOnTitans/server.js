const express = require('express');
const app = express();
const PORT = 3000;

// Servir archivos estáticos (HTML, CSS, JS del navegador)
app.use(express.static('public'));

app.get('/api.attackontitanapi', async (req, res) => {
    try {
        const respuestaLista = await fetch(`https://api.attackontitanapi.com/characters`);

        if (!respuestaLista.ok) {
            return res.status(500).json({ error: 'Error al obtener la lista' });
        }

        const datosLista = await respuestaLista.json();

        // 2. datosLista.results tiene un array. Hacemos fetch (recargas asincronica) a la URL de cada uno de los pokemons
        // Usamos Promise.all para buscar los 15 al mismo tiempo (en paralelo para poder mostarlos juntos)

        // Mapeamos los datos para que coincidan con lo que tu Frontend espera
        // Nota: La API devuelve los resultados en la propiedad 'results'
const listaPersonajes = datosLista.results.slice(0, 20).map(p => ({
            nombre: p.name,
            id: p.id,
            alias: p.alias,
            especies: p.species,
            imagen: p.img,
            tipos: p.gender 
        }));
        // 3. Devolvemos el array con los 15 Personajes al 
        res.json(listaPersonajes);

    } catch (error) {
        res.status(500).json({ error: 'Error al conectar con la API para la lista' });
    }
});

// ============================================
// Iniciar el servidor
// ============================================
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});